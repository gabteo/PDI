/*============================================================================*/
/* M�DULO "GLOBAL"                                                            */
/*----------------------------------------------------------------------------*/
/* Autor: Bogdan T. Nassu - nassu@dainf.ct.utfpr.edu.br                       */
/*============================================================================*/
/** Este m�dulo "global" inclui todos os m�dulos criados para a discipilna
 * de Processamento Digital de Imagens. � apenas uma forma conveniente de se
 * usar os m�dulos, embora o tempo de compila��o possa aumentar pela inclus�o
 * de muito "entulho". */
/*============================================================================*/

#include "imagem.c"
#include "base.c"
#include "cores.c"
#include "geometria.c"
#include "desenho.c"
#include "segmenta.c"
#include "filtros2d.c"

/*============================================================================*/
